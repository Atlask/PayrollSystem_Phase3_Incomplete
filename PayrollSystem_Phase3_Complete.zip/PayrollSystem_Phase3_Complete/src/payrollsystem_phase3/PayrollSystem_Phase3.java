package payrollsystem_phase3;

import java.io.*;
import java.util.*;
import javax.swing.*;

public class PayrollSystem_Phase3 
{
    
    private static Company company;
    private static JFileChooser fileChooser = new JFileChooser(".");
    
    public static void main(String[] args) 
    {
        // initialize the company object
        company = new Company("Our Company", null);

        
        // Ask the user what they want to do.
        String options = "\t [1] to load a new data file\n"
                + "\t [2] to add a new department\n"
                + "\t [3] to add a new hourly employee\n"
                + "\t [4] to add a new salaried employee\n"
                + "\t [5] to add a new manager\n"
                + "\t [6] to display company information\n"
                + "\t [q] to quit the application";
        
        String menuMessage = "Please enter one of the following options:\n" + options;
        String userInput = JOptionPane.showInputDialog(null, menuMessage, "Payroll System", JOptionPane.QUESTION_MESSAGE);
        
        while (userInput != null && !userInput.equalsIgnoreCase("q")) 
        {
            switch (userInput) 
            {
                case "1":
                    importDataFile();
                    break;
                    
                case "2":
                    promptUserForData("D");
                    break;
                    
                case "3":
                    promptUserForData("H");
                    break;
                    
                case "4":
                    promptUserForData("S");                   
                    break;
                    
                case "5":
                    promptUserForData("M");
                    break;
                    
                case "6":
                    System.out.println("******************************************************************");
                    System.out.println("********************** COMPANY INFO ******************************");
                    System.out.println("******************************************************************");
                    System.out.println(company);                                   
                    break;
                    
                default:
                    JOptionPane.showMessageDialog(null, "Invalid entry. Please try again.", 
                            "Invalid entry", JOptionPane.INFORMATION_MESSAGE);
                    break;
            }
            userInput = JOptionPane.showInputDialog(menuMessage);
        }    
        
        JOptionPane.showMessageDialog(null, "Quitting application.");
        
        
        System.exit(0);
    }
    
    
    private static void importDataFile()
    {
        System.out.println("Loading new data file");

        // Prompt the user to select an input data file
        File selectedFile;

        if (fileChooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION)
        {
            selectedFile = fileChooser.getSelectedFile();

            // try with resources. The inputFile Scanner object will be closed automatically.
            try (Scanner inputFile = new Scanner(selectedFile))
            {
                // read all lines of data from the file and process them
                String line;
                int lineNumber = 1;
                while (inputFile.hasNext())
                {
                    line = inputFile.nextLine();
                    try
                    {
                        processLineOfData(line);
                    } 
                    catch (Exception ex)
                    {
                        String message  = "The following error occurred while processing line number "
                                        + lineNumber + ": " + ex.toString()
                                        + "\nLine of data skipped: " + line;
                       
                        System.out.println(message);
                    }
                    lineNumber++;
                }
            } 
            catch (FileNotFoundException e)
            {
                System.out.println(e.toString());
            } 
        
            System.out.println("Done loading data.");
        }
    }
    
    
    private static void promptUserForData(String dataType)
    {
        String dialogMessage, dialogTitle;

        switch (dataType)
        {
            case "D":
                
                dialogMessage   = "Enter department information in this format: dept id,dept name";
                dialogTitle     = "Department Information";
                break;
                
            case "H":
                
                dialogMessage   = "Enter hourly employee information in this format: employee id,first name,\n"
                                + "last name,hourly rate,pay period hours,department id,list of paychecks";
                dialogTitle     = "Hourly Employee Information";
                break;
                
            case "S":
                
                dialogMessage   = "Enter salaried employee information in this format: employee id,first name,\n"
                                + "last name,salary,department id,list of paychecks";
                dialogTitle     = "Salaried Employee Information";
                break;
                
            case "M":
                
                dialogMessage   = "Enter manager information in this format: employee id,first name,last name,\n"
                                + "salary,bonus,department id,list of paychecks";
                dialogTitle     = "Manager Information";
                break;
                
            default:
                return;
        }

        String userInput = JOptionPane.showInputDialog(null, dialogMessage, dialogTitle, JOptionPane.INFORMATION_MESSAGE);
        try
        {
            processLineOfData(dataType + "," + userInput);
        } 
        catch (Exception ex)
        {
            String errorMessage = "The following error occurred while processing the ";
            errorMessage += dialogTitle.toLowerCase() + "you entered: ";

            System.out.println(errorMessage + ex.getMessage());
        }
    }
    
    
    private static void processLineOfData(String line) throws Exception
    {
        String [] lineData = line.split(",");
        ArrayList<Paycheck> list;
        
        int deptID;
        int employeeID;
        
        double hourlyRate;
        double periodHours;
        double salary;
        double bonus;
        
        String departmentName;
        String firstName;
        String lastName;
        String paycheckData;

        String type = lineData[0];
        
        switch (type){
            case "D":
                deptID = Integer.parseInt(lineData[1]);
                departmentName = lineData[2];
                Department inputDept = new Department(deptID, departmentName, null, null);
                company.addDepartment(inputDept);
                break;
                
            case "S":
                employeeID = Integer.parseInt(lineData[1]);
                firstName = lineData[2];
                lastName = lineData[3];
                salary = Double.parseDouble(lineData[4]);
                deptID = Integer.parseInt(lineData[5]);
                paycheckData = lineData[6];
                list = parseEmployeePaychecks(employeeID, paycheckData);
                SalariedEmployee newSalEmp = new SalariedEmployee(employeeID, firstName, lastName, list, salary);
                company.addEmployeeToDepartment(deptID, newSalEmp);
                break;
                        
            case "H":
                employeeID = Integer.parseInt(lineData[1]);
                firstName = lineData[2];
                lastName = lineData[3];
                hourlyRate = Double.parseDouble(lineData[4]);
                periodHours = Double.parseDouble(lineData[5]);
                deptID = Integer.parseInt(lineData[6]);
                paycheckData = lineData[7];               
                list = parseEmployeePaychecks(employeeID, paycheckData);
                HourlyEmployee newHourlyEmployee = new HourlyEmployee(employeeID, firstName, lastName, list, hourlyRate, periodHours);
                company.addEmployeeToDepartment(deptID, newHourlyEmployee);
                break;
                
            case "M":
                employeeID = Integer.parseInt(lineData[1]);
                firstName = lineData[2];
                lastName = lineData[3];
                salary = Double.parseDouble(lineData[4]);
                bonus = Double.parseDouble(lineData[5]);
                deptID = Integer.parseInt(lineData[6]);
                paycheckData = lineData[7];
                list = parseEmployeePaychecks(employeeID, paycheckData);
                Manager newManager = new Manager(employeeID, firstName, lastName, list, salary, bonus);
                company.setDepartmentManager(deptID, newManager);
                break;
            default:
                System.out.println("invalid department");
                throw new Exception("Bad Record");
                
                
                       }
    }
     
    //
    
    public static ArrayList<Paycheck> parseEmployeePaychecks(int empID, String paycheckData)
    {
       
         ArrayList<Paycheck> paycheckElements = new ArrayList<>();

        String paycheckInfo[] = paycheckData.split(",");
        for (String p : paycheckInfo) {
            String[] arr = p.split(":");
            double grossAmount = Double.parseDouble (arr[2]);
            double taxAmount = Double.parseDouble (arr[3]);
            double bonusAmount = Double.parseDouble (arr[4]);

            double netAmount = grossAmount - taxAmount;
            Paycheck pc = new Paycheck(empID, arr[0], arr[1], grossAmount, taxAmount, bonusAmount, netAmount);

            paycheckElements.add(pc);

        }
        return paycheckElements;
    }}
            
            
    
    
    

